# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


    User.destroy_all
    Artwork.destroy_all
    ArtworkShare.destroy_all


    user1, user2, user3, user4 = User.create!([
        {username: "artfan76"}, 
        {username: "starvingartist82"}, 
        {username: "artmonger21"}, 
        {username: "arteest"}
        ])
    
    art1, art2, art3 = Artwork.create!([
        {title: "Mona Lisa", image_url: "www.art.com", artist_id: user1.id},
        {title: "The Last Supper", image_url: "www.art.com", artist_id: user2.id},
        {title: "Guernica", image_url: "www.art.com", artist_id: user3.id}
        ])

    ArtworkShare.create! ([
        {artwork_id: art1.id, viewer_id: user2.id},
        {artwork_id: art1.id, viewer_id: user3.id},
        {artwork_id: art2.id, viewer_id: user4.id}
        ])
